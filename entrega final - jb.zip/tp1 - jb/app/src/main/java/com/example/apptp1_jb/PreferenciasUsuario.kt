package com.example.apptp1_jb

import android.content.Context

class PreferenciasUsuario(context: Context) {

    private val prefs = context.getSharedPreferences("tp1_prefs", Context.MODE_PRIVATE)

    fun guardarUsuario(usuario: Usuario) {
        prefs.edit()
            .putString("nombre", usuario.nombre)
            .putString("email", usuario.email)
            .putString("password", usuario.password)
            .putString("pais", usuario.pais)
            .apply()
    }

    fun obtenerUsuario(): Usuario? {
        val email = prefs.getString("email", null) ?: return null
        return Usuario(
            nombre = prefs.getString("nombre", "") ?: "",
            email = email,
            password = prefs.getString("password", "") ?: "",
            pais = prefs.getString("pais", "") ?: ""
        )
    }
}