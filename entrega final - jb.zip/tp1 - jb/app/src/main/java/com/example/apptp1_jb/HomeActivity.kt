package com.example.apptp1_jb

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Evita que la barra de estado o el teclado tapen el contenido
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.rootHome)) { v, insets ->
            val barras = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(barras.left, barras.top, barras.right, barras.bottom)
            insets
        }

        val tvBienvenida = findViewById<TextView>(R.id.tvBienvenida)
        val tvEmail = findViewById<TextView>(R.id.tvEmailHome)
        val tvPais = findViewById<TextView>(R.id.tvPaisHome)
        val btnSalir = findViewById<Button>(R.id.btnSalir)

        val usuario = PreferenciasUsuario(this).obtenerUsuario()

        if (usuario != null) {
            tvBienvenida.text = getString(R.string.bienvenida, usuario.nombre)
            tvEmail.text = getString(R.string.dato_email, usuario.email)
            tvPais.text = getString(R.string.dato_pais, usuario.pais)
        }

        btnSalir.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}