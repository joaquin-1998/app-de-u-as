package com.example.apptp1_jb.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.apptp1_jb.model.Turno

@Dao
interface TurnoDAO {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun agregarTurno(turno: Turno)

    @Update
    suspend fun actualizarTurno(turno: Turno)

    @Delete
    suspend fun eliminarTurno(turno: Turno)

    @Query("SELECT * FROM turno_table ORDER BY id ASC")
    fun leerTodosLosTurnos(): LiveData<List<Turno>>
}