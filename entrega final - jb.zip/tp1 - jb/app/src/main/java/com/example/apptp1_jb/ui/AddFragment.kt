package com.example.apptp1_jb.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.apptp1_jb.R
import com.example.apptp1_jb.databinding.FragmentAddBinding
import com.example.apptp1_jb.model.Turno
import com.example.apptp1_jb.viewmodel.TurnoViewModel
import java.util.Calendar

class AddFragment : Fragment() {

    private var _binding: FragmentAddBinding? = null
    private val binding get() = _binding!!

    private val turnoViewModel: TurnoViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val servicios = resources.getStringArray(R.array.servicios)
        binding.etServicio.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, servicios)
        )

        binding.etFecha.setOnClickListener { mostrarCalendario() }
        binding.etHora.setOnClickListener { mostrarReloj() }
        binding.btnGuardar.setOnClickListener { guardarTurno() }
    }

    private fun mostrarCalendario() {
        val hoy = Calendar.getInstance()
        DatePickerDialog(
            requireContext(),
            { _, anio, mes, dia ->
                binding.etFecha.setText("%02d/%02d/%d".format(dia, mes + 1, anio))
            },
            hoy.get(Calendar.YEAR),
            hoy.get(Calendar.MONTH),
            hoy.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun mostrarReloj() {
        TimePickerDialog(
            requireContext(),
            { _, hora, minuto ->
                binding.etHora.setText("%02d:%02d".format(hora, minuto))
            },
            10, 0, true
        ).show()
    }

    private fun guardarTurno() {
        val clienta = binding.etClienta.text.toString().trim()
        val servicio = binding.etServicio.text.toString().trim()
        val fecha = binding.etFecha.text.toString().trim()
        val hora = binding.etHora.text.toString().trim()

        if (clienta.isEmpty() || servicio.isEmpty() || fecha.isEmpty() || hora.isEmpty()) {
            Toast.makeText(requireContext(), "Completá todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val turno = Turno(0, clienta, servicio, fecha, hora)
        turnoViewModel.agregarTurno(turno)

        Toast.makeText(requireContext(), "Turno guardado", Toast.LENGTH_SHORT).show()
        findNavController().popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}