package com.example.apptp1_jb.data

import androidx.lifecycle.LiveData
import com.example.apptp1_jb.model.Turno

class TurnoRepository(private val turnoDao: TurnoDAO) {

    val leerTodosLosTurnos: LiveData<List<Turno>> = turnoDao.leerTodosLosTurnos()

    suspend fun agregarTurno(turno: Turno) {
        turnoDao.agregarTurno(turno)
    }

    suspend fun actualizarTurno(turno: Turno) {
        turnoDao.actualizarTurno(turno)
    }

    suspend fun eliminarTurno(turno: Turno) {
        turnoDao.eliminarTurno(turno)
    }
}