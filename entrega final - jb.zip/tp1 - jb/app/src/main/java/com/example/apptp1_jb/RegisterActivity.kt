package com.example.apptp1_jb

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etNombre = findViewById<TextInputEditText>(R.id.etNombre)
        val etEmail = findViewById<TextInputEditText>(R.id.etEmailReg)
        val etPassword = findViewById<TextInputEditText>(R.id.etPasswordReg)
        val etPais = findViewById<MaterialAutoCompleteTextView>(R.id.etPais)
        val paises = resources.getStringArray(R.array.paises_latam)
        etPais.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, paises))
        val cbTerminos = findViewById<CheckBox>(R.id.cbTerminos)
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)

        val preferencias = PreferenciasUsuario(this)

        btnRegistrar.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString()
            val pais = etPais.text.toString().trim()

            if (nombre.isEmpty() || email.isEmpty() || password.isEmpty() || pais.isEmpty()) {
                Toast.makeText(this, getString(R.string.error_campos_vacios), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (!cbTerminos.isChecked) {
                Toast.makeText(this, getString(R.string.error_terminos), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val usuario = Usuario(nombre, email, password, pais)
            preferencias.guardarUsuario(usuario)

            val recuperado = preferencias.obtenerUsuario()
            if (recuperado == usuario) {
                Toast.makeText(this, getString(R.string.registro_ok), Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, getString(R.string.error_guardado), Toast.LENGTH_SHORT).show()
            }
        }
    }
}