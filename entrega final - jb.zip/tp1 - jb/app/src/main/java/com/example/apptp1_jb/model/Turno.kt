package com.example.apptp1_jb.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "turno_table")
data class Turno(
    @PrimaryKey(autoGenerate = true)
    val id: Int,

    @ColumnInfo(name = "clienta")
    val clienta: String,

    @ColumnInfo(name = "servicio")
    val servicio: String,

    @ColumnInfo(name = "fecha")
    val fecha: String,

    @ColumnInfo(name = "hora")
    val hora: String
) : Serializable