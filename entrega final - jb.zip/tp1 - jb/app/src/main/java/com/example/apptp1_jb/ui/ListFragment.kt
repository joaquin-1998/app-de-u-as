package com.example.apptp1_jb.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.apptp1_jb.R
import com.example.apptp1_jb.databinding.FragmentListBinding
import com.example.apptp1_jb.viewmodel.TurnoViewModel

class ListFragment : Fragment() {

    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!

    private val turnoViewModel: TurnoViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Al tocar un turno, vamos a la pantalla de modificar y le mandamos ese turno
        val adapter = TurnoAdapter { turno ->
            val bundle = Bundle().apply { putSerializable("turno", turno) }
            findNavController().navigate(R.id.action_listFragment_to_updateFragment, bundle)
        }
        binding.recyclerViewTurnos.adapter = adapter
        binding.recyclerViewTurnos.layoutManager = LinearLayoutManager(requireContext())

        // Cada vez que cambian los turnos en la base, la lista se actualiza sola
        turnoViewModel.leerTodosLosTurnos.observe(viewLifecycleOwner) { turnos ->
            adapter.setData(turnos)
        }

        // El botón "+" lleva a la pantalla de alta
        binding.fabAgregar.setOnClickListener {
            findNavController().navigate(R.id.action_listFragment_to_addFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}