package com.example.apptp1_jb.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.apptp1_jb.R
import com.example.apptp1_jb.databinding.FragmentUpdateBinding
import com.example.apptp1_jb.model.Turno
import com.example.apptp1_jb.viewmodel.TurnoViewModel
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Calendar

class UpdateFragment : Fragment() {

    private var _binding: FragmentUpdateBinding? = null
    private val binding get() = _binding!!

    private val turnoViewModel: TurnoViewModel by viewModels()

    private lateinit var turnoActual: Turno

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUpdateBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        turnoActual = requireArguments().getSerializable("turno") as Turno

        val servicios = resources.getStringArray(R.array.servicios)
        binding.etServicio.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, servicios)
        )

        binding.etClienta.setText(turnoActual.clienta)
        binding.etServicio.setText(turnoActual.servicio, false)
        binding.etFecha.setText(turnoActual.fecha)
        binding.etHora.setText(turnoActual.hora)

        binding.etFecha.setOnClickListener { mostrarCalendario() }
        binding.etHora.setOnClickListener { mostrarReloj() }
        binding.btnActualizar.setOnClickListener { actualizarTurno() }
        binding.btnEliminar.setOnClickListener { confirmarEliminar() }
    }

    private fun mostrarCalendario() {
        val hoy = Calendar.getInstance()
        DatePickerDialog(
            requireContext(),
            { _, anio, mes, dia ->
                binding.etFecha.setText("%02d/%02d/%d".format(dia, mes + 1, anio))
            },
            hoy.get(Calendar.YEAR),
            hoy.get(Calendar.MONTH),
            hoy.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun mostrarReloj() {
        TimePickerDialog(
            requireContext(),
            { _, hora, minuto ->
                binding.etHora.setText("%02d:%02d".format(hora, minuto))
            },
            10, 0, true
        ).show()
    }

    private fun actualizarTurno() {
        val clienta = binding.etClienta.text.toString().trim()
        val servicio = binding.etServicio.text.toString().trim()
        val fecha = binding.etFecha.text.toString().trim()
        val hora = binding.etHora.text.toString().trim()

        if (clienta.isEmpty() || servicio.isEmpty() || fecha.isEmpty() || hora.isEmpty()) {
            Toast.makeText(requireContext(), "Completá todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val turnoModificado = Turno(turnoActual.id, clienta, servicio, fecha, hora)
        turnoViewModel.actualizarTurno(turnoModificado)

        Toast.makeText(requireContext(), "Turno actualizado", Toast.LENGTH_SHORT).show()
        findNavController().popBackStack()
    }

    private fun confirmarEliminar() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Eliminar turno")
            .setMessage("¿Seguro que querés eliminar el turno de ${turnoActual.clienta}?")
            .setPositiveButton("Sí, eliminar") { _, _ ->
                turnoViewModel.eliminarTurno(turnoActual)
                Toast.makeText(requireContext(), "Turno eliminado", Toast.LENGTH_SHORT).show()
                findNavController().popBackStack()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}