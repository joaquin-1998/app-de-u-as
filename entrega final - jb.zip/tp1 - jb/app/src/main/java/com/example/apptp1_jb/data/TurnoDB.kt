package com.example.apptp1_jb.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.apptp1_jb.model.Turno

@Database(entities = [Turno::class], version = 1, exportSchema = false)
abstract class TurnoDB : RoomDatabase() {

    abstract fun turnoDao(): TurnoDAO

    companion object {
        @Volatile
        private var INSTANCE: TurnoDB? = null

        fun getDatabase(context: Context): TurnoDB {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TurnoDB::class.java,
                    "turno_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}