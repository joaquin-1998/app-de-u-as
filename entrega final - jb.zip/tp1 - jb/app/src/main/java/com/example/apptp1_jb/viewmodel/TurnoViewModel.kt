package com.example.apptp1_jb.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.apptp1_jb.data.TurnoDB
import com.example.apptp1_jb.data.TurnoRepository
import com.example.apptp1_jb.model.Turno
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TurnoViewModel(application: Application) : AndroidViewModel(application) {

    val leerTodosLosTurnos: LiveData<List<Turno>>
    private val repository: TurnoRepository

    init {
        val turnoDao = TurnoDB.getDatabase(application).turnoDao()
        repository = TurnoRepository(turnoDao)
        leerTodosLosTurnos = repository.leerTodosLosTurnos
    }

    fun agregarTurno(turno: Turno) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.agregarTurno(turno)
        }
    }

    fun actualizarTurno(turno: Turno) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.actualizarTurno(turno)
        }
    }

    fun eliminarTurno(turno: Turno) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.eliminarTurno(turno)
        }
    }
}
