package com.example.apptp1_jb.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.apptp1_jb.databinding.ItemTurnoBinding
import com.example.apptp1_jb.model.Turno

class TurnoAdapter(
    private val onItemClick: (Turno) -> Unit
) : RecyclerView.Adapter<TurnoAdapter.TurnoViewHolder>() {

    private var listaTurnos = emptyList<Turno>()

    class TurnoViewHolder(val binding: ItemTurnoBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TurnoViewHolder {
        val binding = ItemTurnoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TurnoViewHolder(binding)
    }

    override fun getItemCount(): Int = listaTurnos.size

    override fun onBindViewHolder(holder: TurnoViewHolder, position: Int) {
        val turno = listaTurnos[position]
        holder.binding.tvClienta.text = turno.clienta
        holder.binding.tvServicio.text = turno.servicio
        holder.binding.tvFechaHora.text = "${turno.fecha} - ${turno.hora}"
        holder.binding.root.setOnClickListener { onItemClick(turno) }
    }

    fun setData(turnos: List<Turno>) {
        listaTurnos = turnos
        notifyDataSetChanged()
    }
}