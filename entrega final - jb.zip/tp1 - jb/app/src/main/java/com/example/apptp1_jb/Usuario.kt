package com.example.apptp1_jb

data class Usuario(
    val nombre: String,
    val email: String,
    val password: String,
    val pais: String
)